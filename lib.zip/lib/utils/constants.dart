import 'package:flutter/material.dart';
const kBackgroundColor = Color(0xFFCCD1D1 );
const kActiveIconColor = Color(0xFFE68342);
const kTextColor = Color(0xFF222B45);
const kblueLightColor = Color(0xFF817DC0);
const kShadowColor = Color(0xFFE6E6E6);
class Constants{
  static const String baseURL = 'https://www.samanoudcity.com/MyApi/public/';
  static const String baseImageURL = 'https://www.samanoudcity.com/MyApi/images/';
}
import 'package:flutter/material.dart';
import 'package:samanoud_city/screen/splash_screen.dart';
import 'package:samanoud_city/screen/welcome_screen.dart';
import 'package:http/http.dart';

void main() => runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: Colors.blueAccent,
        scaffoldBackgroundColor:Colors.blueAccent,
      ),

      home: SplashScreen(),
    ));
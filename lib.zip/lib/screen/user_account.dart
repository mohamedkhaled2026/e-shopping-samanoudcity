import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:io';


class UserAccountPage extends StatefulWidget {
  @override
  _UserAccountPageState createState() => _UserAccountPageState();
}

class _UserAccountPageState extends State<UserAccountPage> {

  //_________________________________________________________________________
  String userName="";
  String userPhone="";
  String userAddress="";
  retriveUserInfo() async{
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    setState(() {
      userName = sharedPreferences.getString('USER_NAME') ?? 'none';
      userPhone = sharedPreferences.getString('USER_PHONE') ?? 'none';
      userAddress = sharedPreferences.getString('USER_ADDRESS') ?? 'none';

    });

    print(sharedPreferences.getString('USER_NAME') ?? 'none');
  }


//_________________  Image Picker Method  ____________________
  File _image ;


  @override
  void initState() {
    super.initState();
    retriveUserInfo();
  }



  //__________________________________________________________________________
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    SystemChrome.setEnabledSystemUIOverlays ([]);
    return Stack(
        children: <Widget>[
         Positioned(
           child: Transform.translate(
             offset: Offset(0,-200),
             child: Container(
               width: size.width,
               height: 450,
               decoration: BoxDecoration(
                 borderRadius: BorderRadius.circular(300),
                 color: Colors.deepPurple[800],
               ),

             ),
           ),
         ),
         Column(
          children: <Widget>[
            SafeArea(child: SizedBox(height: 10,)),
            Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: EdgeInsets.all(5),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Icon(FontAwesomeIcons.arrowLeft,color: Colors.deepPurple,size: 20,),
                  ],
                ),
              ),
            ),
            Text("مرحباً بك فى سوق نو ",style: TextStyle(color:Colors.white,fontFamily: "Cairo",fontWeight: FontWeight.bold),),
            Container(
              height: 140,
              width: 140,
              margin: EdgeInsets.only(top: 5),
              alignment: Alignment.center,
              child: Stack(
                children: <Widget>[
                  Align(
                    alignment: Alignment.center,
                    child: CircleAvatar(
                      radius: 80,
                      backgroundColor: Colors.white,
                      child: ClipOval(
                        child: SizedBox(
                          width: 180,
                          height: 180,
                          child:_image == null ? Icon(FontAwesomeIcons.user , color: Colors.black) :Image.file(_image) ,
                        ),
                      ),
                    ),
                  ),
                  Align(
                    alignment: Alignment.bottomRight,
                    child: Container(
                      height:30 ,
                      width: 30,
                      decoration: BoxDecoration(
                        color: Colors.deepPurple,
                        shape: BoxShape.circle,
                      ),
                      child: Padding(
                        padding: EdgeInsets.all(3),
                        child: Icon(
                          FontAwesomeIcons.pen,
                          color: Colors.white,
                          size: 15,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 20,),
            Column(
              children: <Widget>[
                Text(
                  "الإسم",
                  style: TextStyle(fontWeight: FontWeight.bold,color: Colors.black54,fontSize: 16,fontFamily: "Cairo"),
                ),
                Text(
                  userName,
                  style: TextStyle(fontWeight: FontWeight.bold,color: Colors.deepPurple,fontSize: 20,fontFamily: "Cairo"),
                ),
              ],
            ),
            SizedBox(height: 20,),
            Column(
              children: <Widget>[
                Text(
                  "رقم الهاتف",
                  style: TextStyle(fontWeight: FontWeight.bold,color: Colors.black54,fontSize: 16,fontFamily: "Cairo"),
                ),
                Text(
                  userPhone,
                  style: TextStyle(fontWeight: FontWeight.bold,color: Colors.deepPurple,fontSize: 20,fontFamily: "Cairo"),
                ),
              ],
            ),
            SizedBox(height: 20,),
            Column(
              children: <Widget>[
                Text(
                  "العنوان",
                  style: TextStyle(fontWeight: FontWeight.bold,color: Colors.black54,fontSize: 16,fontFamily: "Cairo"),
                ),
                Text(
                  userAddress,
                  style: TextStyle(fontWeight: FontWeight.bold,color: Colors.deepPurple,fontSize: 20,fontFamily: "Cairo"),
                ),
              ],
            ),

          ],
        ),
        ],
      );
  }
}

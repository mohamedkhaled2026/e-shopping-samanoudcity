import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:modal_progress_hud/modal_progress_hud.dart';
import 'package:samanoud_city/screen/home_page.dart';
import 'package:samanoud_city/ui/round_Button.dart';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:samanoud_city/utils/constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SignUpPage extends StatefulWidget {
  @override
  _SignUpPageState createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  bool processing = false;
  String userName = '';
  String userPassword = '';
  String userPasswordConfirm = '';
  String userPhone = '';
  String userAddress = '';
  int typeId = 1;
  FlutterToast flutterToast;
//2- _______________Updating data over the internet using the http package________________
  dynamic addUser(String userPhone, String userName, String userAddress,
      String userPassword) async {
    http.Response r =
        await http.post('http://samanoudcity.com/MyApi/public/register', body: {
      'USER_PHONE': userPhone,
      'USER_PASSWORD': userPassword,
      'USER_NAME': userName,
      'USER_ADDRESS': userAddress,
      'TYPE_ID': '2',
    });
    print(r.statusCode.toString());
    return jsonDecode(r.body)['message'];
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    flutterToast = FlutterToast(context);
  }

  void showToast(String message) {
    Widget toast = Container(
      padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 12.0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(25.0),
        color: Colors.red,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            message,
            style: TextStyle(
              color: Colors.deepPurple,
              fontSize: 16,
            ),
          ),
        ],
      ),
    );
    flutterToast.showToast(
        child: toast,
        gravity: ToastGravity.TOP,
        toastDuration: Duration(seconds: 3));
  }

  bool validateFields() {
    if (userPhone.length != 11) {
      //faild
      showToast('رقم الهاتف غير صحيح');
      return false;
    } else {
      if (userPassword.length < 7) {
        //faild
        showToast('كلمة المرور قصيرة');
        return false;
      } else {
        if (userPasswordConfirm != userPassword) {
          //faild
          showToast('كلمة المرور غير متطابقة');
          return false;
        } else {
          if (userName.length < 3) {
            //faild
            showToast('اسم قصير');
            return false;
          } else {
            if (userAddress.length < 7) {
              //faild
              showToast('دخل العنوان بالتفصيل');
              return false;
            } else {
              return true;
            }
          }
        }
      }
    }
  }

  Future<Map> getUserInfo(String userPhone) async {
    var response = await http.get(Constants.baseURL + 'getUserInfo/$userPhone');
    if (response.statusCode != 500) {
      print(jsonDecode(response.body)['error']);
      if (jsonDecode(response.body)['error'] == false) {
        print(jsonDecode(utf8.decode(response.bodyBytes)));
        return jsonDecode(utf8.decode(response.bodyBytes));
      } else {
        return jsonDecode(response.body);
      }
    } else {
      Map m = Map();
      m['message'] = 'sever error';
      return m;
    }
  }

  Future<String> storeUserInfo(String userPhone) async {
    Map m = await getUserInfo(userPhone);
    print(m['message']);
    if (m['message'] == 'user exists') {
      SharedPreferences preferences = await SharedPreferences.getInstance();
      preferences.setInt('USER_ID', m['user']['USER_ID']);
      preferences.setString('USER_PHONE', m['user']['USER_PHONE']);
      preferences.setString('USER_NAME', m['user']['USER_NAME']);
      preferences.setString('USER_ADDRESS', m['user']['USER_ADDRESS']);
      preferences.setInt('USER_TYPE', m['user']['USER_TYPE']);
      return 'success';
    } else {
      return 'faild store';
    }
  }

  File _image;
//  Future getImage() async{
//    var image = await ImagePicker.pickImage(source: ImageSource.gallery);
//    setState(() {
//      _image = image ;
//      print('_image: $_image');
//    });
//  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return ModalProgressHUD(
      inAsyncCall: processing,
      child: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.only(top: 30),
          width: double.infinity,
          height: size.height,
          decoration: BoxDecoration(
            gradient: LinearGradient(begin: Alignment.topCenter, colors: [
              Colors.deepPurple[800],
              Colors.deepPurple[500],
              Colors.deepPurple[300],
            ]),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              //Text in the top
              Padding(
                padding: EdgeInsets.all(15),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Align(
                          alignment: Alignment.center,
                          child: CircleAvatar(
                            radius: 60,
                            backgroundColor: Colors.white70,
                            child: ClipOval(
                              child: SizedBox(
                                width: 180,
                                height: 180,
                                child: _image == null
                                    ? Icon(FontAwesomeIcons.plus,
                                        color: Colors.black)
                                    : Image.file(_image),
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(top: 60.0),
                          child: IconButton(
                            icon: Icon(
                              FontAwesomeIcons.camera,
                              size: 30.0,
                              color: Colors.white70,
                            ),
                            onPressed: () {
                              //getImage();
                            },
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              Expanded(
                //the white outSide Container
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(50),
                        topRight: Radius.circular(50)),
                  ),
                  child: Padding(
                    padding: EdgeInsets.all(30),
                    child: Column(
                      children: <Widget>[
                        //The Box of EditText
                        Container(
                          padding: EdgeInsets.all(20),
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(10),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black45,
                                  blurRadius: 20,
                                  offset: Offset(0, 10),
                                )
                              ]),
                          child: Column(
                            children: <Widget>[
                              //userName
                              Container(
                                decoration: BoxDecoration(
                                  border: Border(
                                      bottom:
                                          BorderSide(color: Colors.grey[100])),
                                ),
                                child: TextField(
                                  textAlign: TextAlign.center,
                                  decoration: InputDecoration(
                                    hintText: "رقم الهاتف",
                                    hintStyle: TextStyle(color: Colors.grey),
                                  ),
                                  onChanged: (String value) {
                                    userPhone = value;
                                  },
                                ),
                              ),
                              //EditText of Pone Number
                              Container(
                                decoration: BoxDecoration(
                                  border: Border(
                                      bottom:
                                          BorderSide(color: Colors.grey[100])),
                                ),
                                child: TextField(
                                  textAlign: TextAlign.center,
                                  obscureText: true,
                                  decoration: InputDecoration(
                                    hintText: "كلمة المرور",
                                    hintStyle: TextStyle(color: Colors.grey),
                                  ),
                                  onChanged: (String value) {
                                    userPassword = value;
                                  },
                                ),
                              ),

                              SizedBox(
                                height: 10,
                              ),

                              //EditText of Password
                              Container(
                                decoration: BoxDecoration(
                                  border: Border(
                                      bottom:
                                          BorderSide(color: Colors.grey[100])),
                                ),
                                child: TextField(
                                  textAlign: TextAlign.center,
                                  obscureText: true,
                                  decoration: InputDecoration(
                                    hintText: "تاكيد كلمة المرور",
                                    hintStyle: TextStyle(color: Colors.grey),
                                    //                                  border: InputBorder.none
                                  ),
                                  onChanged: (String value) {
                                    userPasswordConfirm = value;
                                  },
                                ),
                              ),

                              SizedBox(
                                height: 10,
                              ),

                              Container(
                                decoration: BoxDecoration(
                                  border: Border(
                                      bottom:
                                          BorderSide(color: Colors.grey[100])),
                                ),
                                child: TextField(
                                  textAlign: TextAlign.center,
                                  decoration: InputDecoration(
                                    hintText: "اسم المستخدم",
                                    hintStyle: TextStyle(color: Colors.grey),
                                  ),
                                  onChanged: (value) {
                                    userName = value;
                                  },
                                ),
                              ),
                              //Address
                              Container(
                                decoration: BoxDecoration(
                                  border: Border(
                                      bottom:
                                          BorderSide(color: Colors.grey[100])),
                                ),
                                child: TextField(
                                  textAlign: TextAlign.center,
                                  decoration: InputDecoration(
                                    hintText: "عنوان المستخدم",
                                    hintStyle: TextStyle(color: Colors.grey),
                                  ),
                                  onChanged: (String value) {
                                    userAddress = value;
                                  },
                                ),
                              ),

                              SizedBox(
                                height: 10,
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 20,
                        ),

                        //logIn Button
                        RoundedButton(
                          text: 'تسجيل',
                          color: Colors.deepPurple,
                          textColor: Colors.white,
                          press: () async {
                            setState(() {
                              processing = true;
                            });
                            if (validateFields()) {
                              dynamic r = await addUser(
                                  userPhone, userName, userAddress, userPassword);
                              if (r == 'user created successfully') {
                                storeUserInfo(userPhone);
                                Navigator.pushReplacement(context,
                                    MaterialPageRoute(builder: (context) {
                                  return HomePage();
                                }));
                              } else {
                                setState(() {
                                  processing = false;
                                });
                                showToast('لم يتم التسجيل');
                              }
                            } else {
                              setState(() {
                                processing = false;
                              });
                            }
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

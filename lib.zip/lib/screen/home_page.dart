import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:samanoud_city/screen/categories_page.dart';
import 'package:samanoud_city/screen/user_account.dart';
import 'cart.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Widget container = CategoriesPage();
  var _currentIndex=1;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return WillPopScope(
      onWillPop: ()async {
        if(_currentIndex == 1){
          return true;
        }else{
          setState(() {
            container = CategoriesPage();
            _currentIndex = 1;
          });
          return false;
        }
      },
      child: Scaffold(
        backgroundColor: Colors.white70,
        body: container,
        bottomNavigationBar: BottomNavigationBar(
          currentIndex: _currentIndex,
          items: [
            BottomNavigationBarItem(
              icon: Icon(Icons.person,size: 30,),
              title: Text("حسابى", style: TextStyle(fontWeight: FontWeight.bold,fontFamily: "Cairo")),
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.category,size: 30),
              title: Text("الفئات", style: TextStyle(fontWeight: FontWeight.bold,fontFamily: "Cairo")),
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.shopping_cart,size: 30),
              title: Text("سلتى", style: TextStyle(fontWeight: FontWeight.bold,fontFamily: "Cairo")),
            ),
          ],
          onTap: (index){
            setState(() {
              if(index == 0){
                _currentIndex = index;
                container = UserAccountPage();
              }
              else if(index ==1){
                _currentIndex = index;
                container = CategoriesPage();
              }
              else if(index ==2){
                _currentIndex =index;
                container = CartPage();
              }
            });

          },

          type: BottomNavigationBarType.fixed,
          selectedItemColor: Colors.deepPurple,
        ),
      ),
    );
  }
}

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:samanoud_city/ui/cart_card.dart';
import 'package:samanoud_city/utils/SQLHelper.dart';
import 'package:samanoud_city/utils/constants.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class CartPage extends StatefulWidget {
  @override
  _CartPage createState() => _CartPage();
}

class _CartPage extends State<CartPage> {
  var db = SQLHELPER();
  int quantity = 1;
  int userID;
  int providerID;
  String userOrder;
  FlutterToast flutterToast;
  Future<String> addOrder(int userID,int providerID,String userOrder) async{

    var response = await http.post(Constants.baseURL+'addOrder',
        body: {'USER_ID': userID.toString(), 'PROVIDER_ID': providerID.toString(),'USER_ORDER':userOrder});
    if(response.statusCode != 500){
      if(jsonDecode(response.body)['error'] == 'false'){
        return jsonDecode(response.body)['message'];
      }else{
        return jsonDecode(response.body)['message'];
      }
    }else{
      return 'sever error';
    }

  }

  retriveUserInfo() async{
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    userID =  sharedPreferences.getInt('USER_ID') ?? -1;

  }
  void showToast(String message){
    Widget toast = Container(
      padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 12.0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(25.0),
        color: Colors.green,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(message,style: TextStyle(
            color: Colors.deepPurple,
            fontSize: 16,
          ),),
        ],
      ),
    );
    flutterToast.showToast(child: toast,gravity: ToastGravity.TOP,toastDuration: Duration(seconds: 3));
  }
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    flutterToast = FlutterToast(context);
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setEnabledSystemUIOverlays([]);
    return SafeArea(
      child:
          Container(
            child: FutureBuilder<List<dynamic>>(
              future: db.getProviders(),
              builder: (context, snapshot) {
                print(snapshot.hasData);
                if (snapshot.hasData) {
                  if (snapshot.data.length != 0) {
                    return ListView.builder(
                      shrinkWrap: true,
                      itemCount: snapshot.data.length,
                      itemBuilder: (context, index) {
                        return Column(children: <Widget>[
                          Container(
                            height: 50.0,
                            color: Colors.purple,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: <Widget>[
                                Text(
                                    snapshot.data[index].cast<String,
                                        dynamic>()['PROVIDER_NAME'],
                                    style: new TextStyle(
                                        fontSize: 20.0, color: Colors.white)),
                                GestureDetector(
                                  onTap: () async {
                                    await retriveUserInfo();
                                    providerID = snapshot.data[index].cast<String, dynamic>()['PROVIDER_ID'];
                                    userOrder = (await db.getProductsForSpecificProviderForOrder(providerID)).toString();
                                    await addOrder(userID, providerID, userOrder);
                                    showToast('تم طلب الاوردر');
                                    db.deleteProvider(providerID);
                                    setState(() {
                                      db.getProviders();
                                    });
                                  },
                                  child: Row(
                                    children: <Widget>[
                                      Icon(
                                        Icons.attach_money,
                                        color: Colors.white,
                                      ),
                                      Text('اطلب',
                                          style: new TextStyle(
                                              fontSize: 20.0,
                                              color: Colors.white))
                                    ],
                                  ),
                                )
                              ],
                            ),
                          ),
                          Container(
                            height: 250,
                            child: FutureBuilder<List<dynamic>>(
                              future: db.getProductsForSpecificProvider(snapshot
                                  .data[index]
                                  .cast<String, dynamic>()['PROVIDER_ID']),
                              builder: (context, snapshot) {
                                bool isNull = false;
                                isNull = snapshot.hasData;
                                if (snapshot.hasData) {
                                  return ListView.builder(
                                    shrinkWrap: true,
                                    scrollDirection: Axis.horizontal,
                                    itemBuilder:
                                        (BuildContext context, int index) {
                                      Map<String, dynamic> cartProduct =
                                          snapshot.data[index]
                                              .cast<String, dynamic>();
                                      return Container(
                                          margin: EdgeInsets.all(5),
                                          child: CartCard(
                                            image: cartProduct['PRODUCT_IMAGE'],
                                            title: cartProduct['PRODUCT_NAME'],
                                            price: cartProduct['PRODUCT_PRICE'],
                                            quantity:
                                                cartProduct['PRODUCT_QUANTITY'],
                                            deletePress: () {
                                              db.deleteProduct(
                                                  cartProduct['PRODUCT_ID']);
                                              setState(() {
                                                db.getProviders();
                                              });
                                            },
                                            updatePress: () {
                                              quantity = cartProduct[
                                                  'PRODUCT_QUANTITY'];
                                              showModalBottomSheet(
                                                  context: context,
                                                  builder:
                                                      (BuildContext context) {
                                                    return StatefulBuilder(
                                                        builder: (BuildContext
                                                                context,
                                                            StateSetter
                                                                mystate) {
                                                      return Container(
                                                        child: Center(
                                                          child: Column(
                                                            children: <Widget>[
                                                              Row(
                                                                children: <
                                                                    Widget>[
                                                                  IconButton(
                                                                    icon: Icon(
                                                                        Icons
                                                                            .add),
                                                                    onPressed:
                                                                        () {
                                                                      mystate(
                                                                          () {
                                                                        quantity++;
                                                                      });
                                                                    },
                                                                  ),
                                                                  Text(quantity
                                                                      .toString()),
                                                                  IconButton(
                                                                    icon: Icon(Icons
                                                                        .remove),
                                                                    onPressed:
                                                                        () {
                                                                      if (!(quantity <=
                                                                          1)) {
                                                                        mystate(
                                                                            () {
                                                                          quantity--;
                                                                        });
                                                                      }
                                                                    },
                                                                  )
                                                                ],
                                                              ),
                                                              IconButton(
                                                                icon: Icon(Icons
                                                                    .add_shopping_cart),
                                                                onPressed:
                                                                    () async {
                                                                  db.updateProduct(
                                                                      cartProduct[
                                                                          'PRODUCT_ID'],
                                                                      quantity);
                                                                  setState(() {
                                                                    db.getProviders();
                                                                  });
                                                                  Navigator.pop(
                                                                      context);
                                                                },
                                                              )
                                                            ],
                                                          ),
                                                        ),
                                                      );
                                                    });
                                                  });
                                            },
                                          ));
                                    },
                                    itemCount: snapshot.data.length,
                                  );
                                } else {
                                  if (!isNull) {
                                    return Center(
                                        child: CircularProgressIndicator(
                                      backgroundColor: Colors.green,
                                    ));
                                  } else {
                                    return Center(
                                      child: Text(
                                          'لا يوجد منتجات داخل سلتك الخاصة'),
                                    );
                                  }
                                }
                              },
                            ),
                          ),
                        ]);
                      },
                    );
                  } else {
                    return Padding(padding: EdgeInsets.only(top: 50),child: Text('لا يوجد منتجات في السلة',style: TextStyle(fontSize: 26),));
                  }
                } else {
                  return Center(
                      child: CircularProgressIndicator(
                    backgroundColor: Colors.green,
                  ));
                }
              },
            ),
          ),
    );
  }
}

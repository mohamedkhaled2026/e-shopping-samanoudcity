import 'dart:async';
import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:modal_progress_hud/modal_progress_hud.dart';
import 'package:samanoud_city/ui/round_Button.dart';
import 'package:http/http.dart' as http;
import 'package:samanoud_city/utils/constants.dart';
import 'home_page.dart';
import '../ui/round_Button.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:fluttertoast/fluttertoast.dart';

class LoginPage extends StatefulWidget {
  @override
  LoginPage_State createState() => LoginPage_State();
}

class LoginPage_State extends State<LoginPage> {
  bool processing = false;
  FlutterToast flutterToast;
  String userPhone = '',userPassword = '';
  Future<String> logIN(String userPhone,String userPassword) async{

    var response = await http.post(Constants.baseURL+'logIn',
        body: {'USER_PHONE': userPhone, 'USER_PASSWORD': userPassword});
    if(response.statusCode != 500){
      if(jsonDecode(response.body)['error'] == 'false'){
        return jsonDecode(response.body)['message'];
      }else{
        return jsonDecode(response.body)['message'];
      }
    }else{
      return 'sever error';
    }

  }

  Future<Map>getUserInfo(String userPhone) async{

    var response = await http.get(Constants.baseURL+'getUserInfo/$userPhone');
    if(response.statusCode != 500){
      print(jsonDecode(response.body)['error']);
      if(jsonDecode(response.body)['error'] == false){
        print(jsonDecode(utf8.decode(response.bodyBytes)));
        return jsonDecode(utf8.decode(response.bodyBytes));

      }else{
        return jsonDecode(response.body);
      }
    }else{
      Map m = Map();
      m['message'] = 'sever error';
      return m;
    }
  }
  Future<String> storeUserInfo(String userPhone)async{
    Map m = await getUserInfo(userPhone);
    print(m['message']);
    if(m['message'] == 'user exists') {
      SharedPreferences preferences = await SharedPreferences.getInstance();
      preferences.setInt('USER_ID', m['user']['USER_ID']);
      preferences.setString('USER_PHONE', m['user']['USER_PHONE']);
      preferences.setString('USER_NAME', m['user']['USER_NAME']);
      preferences.setString('USER_ADDRESS', m['user']['USER_ADDRESS']);
      preferences.setInt('USER_TYPE', m['user']['USER_TYPE']);
      return'success';
    }else{
      return 'faild store';
    }
  }
  void showToast(String message){
    Widget toast = Container(
      padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 12.0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(25.0),
        color: Colors.red,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(message,style: TextStyle(
            color: Colors.deepPurple,
            fontSize: 16,
          ),),
        ],
      ),
    );
    flutterToast.showToast(child: toast,gravity: ToastGravity.TOP,toastDuration: Duration(seconds: 3));
  }
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    flutterToast = FlutterToast(context);
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return ModalProgressHUD(
      inAsyncCall: processing,
      child: SingleChildScrollView(
          child: Container(

            padding: EdgeInsets.only(top: 20),
            width: double.infinity,
            height: size.height,
            decoration: BoxDecoration(
              gradient: LinearGradient(begin: Alignment.topCenter, colors: [
                Colors.deepPurple[800],
                Colors.deepPurple[500],
                Colors.deepPurple[300],
              ]),
            ),


            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                SizedBox(height: 40),

                //Text in the top
                Padding(
                  padding: EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      Text(
                        "تسجيل الدخول",
                        style: TextStyle(color: Colors.white, fontSize: 40,fontFamily: 'Pacifico'),

                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Text(
                        "مرحبا بعودتك",
                        style: TextStyle(color: Colors.white, fontSize: 20,fontFamily: 'Pacifico'),
                      ),
                    ],
                  ),
                ),

                SizedBox(
                  height: 5,
                ),

                Expanded(
                  //the white outSide Container
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(50),
                          topRight: Radius.circular(50)),
                    ),

                    child: Padding(
                      padding: EdgeInsets.all(30),
                      child: Column(
                        children: <Widget>[
                          SizedBox(height: 10,),
                          //The Box of EditText
                          Container(
                            padding: EdgeInsets.all(20),
                            decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(10),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black45,
                                    blurRadius: 20,
                                    offset: Offset(0, 10),
                                  )
                                ]),

                            child: Column(
                              children: <Widget>[

                                //EditText of Pone Number
                                Container(
                                  decoration: BoxDecoration(
                                    border: Border(
                                        bottom:
                                        BorderSide(color: Colors.grey[200])),
                                  ),
                                  child: TextField(
                                    textAlign: TextAlign.center,
                                    decoration: InputDecoration(
                                      hintText: "رقم الهاتف",
                                      hintStyle: TextStyle(color: Colors.grey),
                                    ),
                                    onChanged: (String value){
                                      userPhone = value;
                                    },
                                  ),
                                ),

                                //EditText of Password
                                Container(
                                  decoration: BoxDecoration(
                                    border: Border(
                                        bottom:
                                        BorderSide(color: Colors.grey[200])),
                                  ),
                                  child: TextField(
                                    textAlign: TextAlign.center,
                                    obscureText: true,
                                    decoration: InputDecoration(
                                      hintText: "كلمة المرور",
                                      hintStyle: TextStyle(color: Colors.grey),
//                                    border: InputBorder.none
                                    ),
                                    onChanged: (String value){
                                      userPassword = value;
                                    },
                                  ),
                                ),
                                SizedBox(height: 10,),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 40,
                          ),

                          Text(
                            "نسيت كلمة المرور",
                            style: TextStyle(
                              color: Colors.grey,
                            ),
                          ),
                          SizedBox(
                            height: 20,
                          ),

                          //logIn Button
                          RoundedButton(
                            text: 'دخول',
                            color: Colors.deepPurple,
                            textColor: Colors.white,
                            press:() async{
                              setState(() {
                                processing = true;
                              });

                              if(userPhone.trim().isEmpty ||userPassword.trim().isEmpty){
                                showToast('من فضلك املأ الحقول');
                                print('enter all fields');
                                setState(() {
                                  processing = false;
                                });

                              }else{
                                String result = await logIN(userPhone, userPassword);

                                if(result == 'user logined successfully'){
                                  String r = await storeUserInfo(userPhone);
                                  if(r == 'success') {
                                    Navigator.pushReplacement(context,
                                        MaterialPageRoute(builder: (context) {
                                          return HomePage();
                                        }));
                                  }else{
                                    print(r);
                                  }
                                }else{
                                  showToast("رقم الهاتف او كلمة المرور غير صحيحة");
                                }
                                setState(() {
                                  processing = false;
                                });
                              }
                            },
                          ),
                          SizedBox(
                            height: 20 ,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
    );
  }
}

import 'dart:async';
import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:samanoud_city/screen/provider_page.dart';
import 'package:samanoud_city/ui/providers_card.dart';
import 'package:samanoud_city/utils/constants.dart';

class ProvidersPage extends StatefulWidget {
  final int categoryID;
  final String categoryName;
  final String categoryPanner;
  ProvidersPage(
      this.categoryID,
      this.categoryName,
      this.categoryPanner,
      );
  @override
  _ProvidersPageState createState() => _ProvidersPageState();
}

class _ProvidersPageState extends State<ProvidersPage> {

  bool isNull = false;
  String searchWord = '';
  Widget searching  = Text('');


  Future<List<dynamic>> getAllpROVIDERS() async {
    if(searchWord == '') {
      http.Response response =
      await http.get(Constants.baseURL + 'getProviders/${widget.categoryID}');
      if (response.statusCode == 201) {
        return jsonDecode(utf8.decode(response.bodyBytes))['providers'];
      } else {
        isNull = true;
        return null;
      }
    }else{
      http.Response response =
      await http.post(Constants.baseURL + 'getSpecificProvidersForSpecificCategory',body: {
        'CATEGORY_ID':widget.categoryID.toString(),
        'SEARSH_WORD':searchWord
      });
      if (response.statusCode == 201) {
        return jsonDecode(utf8.decode(response.bodyBytes))['providers'];
      } else {
        isNull = true;
        Widget processing = Center(child: CircularProgressIndicator(
          backgroundColor: Colors.deepPurple,
        ));
        return null;
      }
    }
  }



  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.white70,
      body: Container(
        child: Column(
          children: <Widget>[
            Stack(
              children: <Widget>[
                //_______________ shop Image ______________

                Container(
                  height: size.height * .25,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    image: DecorationImage(image: NetworkImage(Constants.baseImageURL+widget.categoryPanner),
                        fit: BoxFit.cover),
                  ),
                  child: Container(
                    alignment: Alignment.bottomCenter,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: Colors.black.withOpacity(0.2),
                    ),
                  ),
                ),
                Positioned(
                  left: 20,
                  top: 40,
                  child: Container(
                    height: 40,
                    width: 40,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle, color: Colors.white),
                    child: IconButton(
                      icon: Icon(
                        Icons.arrow_back,
                        size: 20,
                      ),
                      onPressed: () {
                        Navigator.pop(context);
                      },
                    ),
                  ),
                ),
                SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: Column(
                      children: <Widget>[
                        Container(
                          padding: EdgeInsets.only(right: 10),
                          alignment: Alignment.topRight,
                          child: Text(
                            widget.categoryName,
                            style: TextStyle(fontSize: 30,fontWeight: FontWeight.bold,fontFamily: "Cairo",color: Colors.white),
                          ),
                        ),
                        searching,
                        Container(
                          padding: EdgeInsets.only(right: 25 ,left: 25),
                          margin: EdgeInsets.symmetric(vertical: 20),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(29.5),
                          ),
                          child: TextField(
                            decoration: InputDecoration(
                              suffixIcon: Icon(Icons.search,),
                              border: InputBorder.none,
                              hintStyle: TextStyle(fontSize: 16),
                              hintText: "بحث",
                            ),
                            textDirection: TextDirection.rtl,
                            textAlign: TextAlign.right,
                            onChanged: (value){
                              setState(() {
                                searching = CircularProgressIndicator(
                                  backgroundColor: Colors.deepPurple,
                                );
                              });
                              searchWord = value;
                              setState(() {
                                getAllpROVIDERS();
                              });
                              Timer(Duration(milliseconds: 100), (){
                                setState(() {
                                  searching = Text('');
                                });
                              });
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            Expanded(
            child: FutureBuilder<List<dynamic>>(
              future: getAllpROVIDERS(),
              builder: (context,snapshot) {
                if(snapshot.hasData){
                  return GridView.builder(
                    gridDelegate:  SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 1,
                      childAspectRatio: 2.2,
                    ),
                    itemBuilder: (BuildContext  context, int  index) {
                      Map<String, dynamic> cat =
                      snapshot.data[index].cast<String, dynamic>();
                      return ProvidersCard(
                        title: cat['USER_NAME'],
                        img: Constants.baseImageURL +
                            cat['PROVIDER_IMAGE'],
                        Press: (){
                          Navigator.push(this.context, MaterialPageRoute(builder: (context){
                            return ProviderPage(cat);
                          }));
                        },
                      );
                    },
                    itemCount: snapshot.data.length ,
                  );
                }else{
                  if(!isNull) {
                    return Center(child: CircularProgressIndicator(
                      backgroundColor: Colors.deepPurple,
                    ));
                  }else{
                    return Center(
                      child: Text(
                          'لا يوجد محلات لهذا القسم بعد'
                      ),
                    );
                  }
                }
              },
            ),
          ),
          ],
        ),
      ),
    );
  }
}

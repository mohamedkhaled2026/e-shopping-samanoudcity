import 'package:flutter/material.dart';
import 'package:samanoud_city/screen/cart.dart';
import 'package:samanoud_city/screen/categories_page.dart';
import 'package:samanoud_city/screen/user_account.dart';
class BottomNavBar extends StatefulWidget {
  @override
  _BottomNavBarState createState() => _BottomNavBarState();
}

class _BottomNavBarState extends State<BottomNavBar> {
  var _currentIndex=1;

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      currentIndex: _currentIndex,
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.person,size: 30,),
            title: Text("حسابى", style: TextStyle(fontWeight: FontWeight.bold,fontFamily: "Cairo")),
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.category,size: 30),
            title: Text("الفئات", style: TextStyle(fontWeight: FontWeight.bold,fontFamily: "Cairo")),
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.shopping_cart,size: 30),
            title: Text("سلتى", style: TextStyle(fontWeight: FontWeight.bold,fontFamily: "Cairo")),
          ),
        ],
        onTap: (index){
          setState(() {
            if(index == 0){
              _currentIndex = index;
              print(_currentIndex);
            }
            else if(index ==1){
              print(_currentIndex);
            }
            else if(index ==2){
              _currentIndex =index;
              print(_currentIndex);
            }
          });

        },
      type: BottomNavigationBarType.fixed,
      selectedItemColor: Colors.deepPurple,
      );
  }
}

import 'dart:async';
import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:modal_progress_hud/modal_progress_hud.dart';
import 'package:samanoud_city/ui/gridItem.dart';
import 'package:samanoud_city/utils/constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ProvidersPage extends StatefulWidget {
  final int categoryID;
  ProvidersPage(this.categoryID);
  @override
  _ProvidersPageState createState() => _ProvidersPageState();
}

class _ProvidersPageState extends State<ProvidersPage> {

  String user = '';

  retriveUserInfo() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    setState(() {
      user = sharedPreferences.getString('USER_NAME') ?? 'none';
    });

  }

  Future<List<dynamic>> getAllCategories() async {
    http.Response response =
    await http.get(Constants.baseURL + 'getProviders/${widget.categoryID}');
    print(response.statusCode);
    if (response.statusCode == 201) {
      return jsonDecode(utf8.decode(response.bodyBytes))['providers'];
    } else {
      return null;
    }
  }



  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    retriveUserInfo();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Souqنoud',
          textAlign: TextAlign.center,
        ),
      ),
      drawer: Drawer(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                user,
                style: TextStyle(color: Colors.blue),
              ),
            ],
          )),
      body: Container(
        child: FutureBuilder<List<dynamic>>(
          future: getAllCategories(),
          builder: (context,snapshot) {
            if(snapshot.hasData){
              return GridView.builder(
                gridDelegate:  SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  childAspectRatio: 0.8,
                ),
                itemBuilder: (BuildContext  context, int  index) {
                  Map<String, String> cat =
                  snapshot.data[index].cast<String, String>();
                  print(snapshot.data[0]);

                  return GridItem(
                    text: cat['USER_NAME'],
                    imageUrl: Constants.baseImageURL +
                        'electric-device.png',
                    onPress: (){
                      print(index);
                    },
                  );
                },
                itemCount: snapshot.data.length ,
              );
            }else{
              return Center(child: CircularProgressIndicator(
                backgroundColor: Colors.green,
              ));
            }
          },
        ),
      ),
    );
  }
}

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class SignUpPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.only(top: 30),
          width: double.infinity,
          height: size.height,
          decoration: BoxDecoration(
            gradient: LinearGradient(begin: Alignment.topCenter, colors: [
              Colors.deepPurple[800],
              Colors.deepPurple[500],
              Colors.deepPurple[300],
            ]),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              SizedBox(height: 80),

              //Text in the top
              Padding(
                padding: EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Text(
                      "Sign Up",
                      style: TextStyle(color: Colors.white, fontSize: 40),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Text(
                      "Welcome With Us",
                      style: TextStyle(color: Colors.white, fontSize: 20),
                    ),
                  ],
                ),
              ),

              SizedBox(
                height: 50,
              ),

              Expanded(
                //the white outSide Container
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(50),
                        topRight: Radius.circular(50)),
                  ),
                  child: Padding(
                    padding: EdgeInsets.all(30),
                    child: Column(
                      children: <Widget>[
                        //The Box of EditText
                        Container(
                          padding: EdgeInsets.all(20),
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(10),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black45,
                                  blurRadius: 20,
                                  offset: Offset(0, 10),
                                )
                              ]),
                          child: Column(
                            children: <Widget>[
                              //EditText of Pone Number
                              Container(
                                decoration: BoxDecoration(
                                  border: Border(
                                      bottom:
                                          BorderSide(color: Colors.grey[100])),
                                ),
                                child: TextField(
                                  decoration: InputDecoration(
                                    hintText: "Phone number",
                                    hintStyle: TextStyle(color: Colors.grey),
                                  ),
                                ),
                              ),

                              SizedBox(height: 10,),

                              //EditText of Password
                              Container(
                                decoration: BoxDecoration(
                                  border: Border(
                                      bottom:
                                          BorderSide(color: Colors.grey[100])),
                                ),
                                child: TextField(
                                  obscureText: true,
                                  decoration: InputDecoration(
                                    hintText: "Password",
                                    hintStyle: TextStyle(color: Colors.grey),
                                    //                                  border: InputBorder.none
                                  ),
                                ),
                              ),

                              SizedBox(height: 10,),

                              Container(
                                decoration: BoxDecoration(
                                  border: Border(
                                      bottom:
                                      BorderSide(color: Colors.grey[100])),
                                ),
                                child: TextField(
                                  obscureText: true,
                                  decoration: InputDecoration(
                                    hintText: "Confirm Password",
                                    hintStyle: TextStyle(color: Colors.grey),
                                    //                                  border: InputBorder.none
                                  ),
                                ),
                              ),

                              SizedBox(height: 10,),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 40,
                        ),

                        SizedBox(
                          height: 20,
                        ),

                        //logIn Button
                        Expanded(
                          child: Container(
                            height: 50,
                            margin: EdgeInsets.only(right: 5,left: 5),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                                gradient: LinearGradient(begin: Alignment.bottomCenter, colors: [
                                  Colors.blue[500],
                                  Colors.blue[300],
                                ]),
                            ),
                            child: Center(
                              child: Text(
                                "Sing Up",
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize:18,
                                    fontWeight: FontWeight.bold),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                            height: 10,
                        ),
                        Text(
                          "Have an account?Login",
                          style: TextStyle(color: Colors.black54,fontSize: 16,fontWeight: FontWeight.w900),
                        ),
                        SizedBox(
                          height: 20,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

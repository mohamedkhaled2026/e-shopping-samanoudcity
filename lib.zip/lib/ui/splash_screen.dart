import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:samanoud_city/ui/round_Button.dart';
import 'package:samanoud_city/ui/singup_page.dart';

import 'login_page.dart';

class WelcomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topCenter, colors: [
            Colors.deepPurple[800],
            Colors.deepPurple[500],
            Colors.deepPurple[300],
          ]),
        ),
          child: Center(
            child: Center(
              child: Column(

                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  SizedBox(height: 80,),
                  Text(
                    "Wilcome to Souq Noud " ,
                    style: TextStyle(
                      fontSize: 20 ,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Pacifico',
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(height: size.height * 0.1,),
                  Image (
                    image: AssetImage('images/splash1.png'),
                    width: size.width,
                    height: 300,
                    alignment: Alignment.center,
                    fit: BoxFit.fitWidth,
                  ),
//                CircleAvatar(
//                  radius: 100.0,
//                  backgroundColor: Colors.white,
//                  backgroundImage: AssetImage('images/splash1.png'),
//                ),
                  SizedBox(height: 40,),
                  RoundedButton(
                    text: 'LOGIN',
                    color: Colors.deepPurple,
                    press:(){Navigator.push(context, MaterialPageRoute(builder: (context){return LoginPage();}));},
                  ),
                  SizedBox(height: 10,),
                  RoundedButton(
                    text: 'SIGN UP',
                    color: Color(0xFFD52550),
                    textColor: Colors.white,
                    press:(){Navigator.push(context, MaterialPageRoute(builder: (context){return SignUpPage();}));},
                  ),
                ],
              ),
            ),
          ),
        ),
    );
  }
}








